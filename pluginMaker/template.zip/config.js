export default {
    "name": "template",
    "title": "新建插件例子",
    "intro": "描述您新建的插件例子",
    "version": "0.0.1",
    "author": "作者名",
    "website": "站点地址",
    "state": "active",
    "creatTime": "2024-01-01",
    "updateTime": "2024-01-01",
    "require": [],
    "tvtstore": 'LOCAL',
    "preview": [{
        "src": "plugins/basic/base/preview/theBasic.png",
        "type": "img",
        "name": "index",
        "title": "实例",
        disableFPSGraph: false,
        disableSrcBtn: false
    }, ]
}